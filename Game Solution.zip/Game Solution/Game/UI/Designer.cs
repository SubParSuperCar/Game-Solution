﻿#if DEBUG

using System;
using Avalonia;

namespace Game.UI;

internal static class Designer
{
	public static int Main()
	{
		throw new NotSupportedException("This project isn't meant to be run: it's only for Avalonia designer support.");
	}

	// Used by designer
	// ReSharper disable once UnusedMember.Global
	public static AppBuilder BuildAvaloniaApp()
	{
		return AppBuilder
			.Configure<App>()
			.UseSkia();
	}
}

#endif
