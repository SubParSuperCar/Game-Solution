using Avalonia;
using Avalonia.Controls;

namespace Game.UI;

public sealed class DirectionalFocusControl : AvaloniaObject
{
	public static readonly StyledProperty<Control?> ControlProperty =
		AvaloniaProperty.Register<DirectionalFocusControl, Control?>(nameof(Control));

	public static readonly StyledProperty<bool> IsNewRowProperty =
		AvaloniaProperty.Register<DirectionalFocusControl, bool>(nameof(IsNewRow));

	public static readonly StyledProperty<bool> IsRowDefaultProperty =
		AvaloniaProperty.Register<DirectionalFocusControl, bool>(nameof(IsRowDefault));

	public Control? Control
	{
		get => GetValue(ControlProperty);
		set => SetValue(ControlProperty, value);
	}

	public bool IsNewRow
	{
		get => GetValue(IsNewRowProperty);
		set => SetValue(IsNewRowProperty, value);
	}

	public bool IsRowDefault
	{
		get => GetValue(IsRowDefaultProperty);
		set => SetValue(IsRowDefaultProperty, value);
	}
}
