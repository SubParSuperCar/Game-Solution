﻿using System.Diagnostics.CodeAnalysis;
using CommunityToolkit.Mvvm.ComponentModel;

namespace Game.UI;

public sealed partial class UiOptions : ObservableObject
{
	[ObservableProperty] private bool _fullscreen;

	[ObservableProperty] private bool _showFps = true;

	[ObservableProperty]
	[SuppressMessage("ReSharper", "InconsistentNaming", Justification = "Name required for correct property generation")]
	private double _UIScale = 1.0;

	[ObservableProperty] private bool _vSync = true;
}
